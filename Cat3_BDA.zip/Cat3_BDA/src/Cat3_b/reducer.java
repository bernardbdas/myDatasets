package Cat3_b;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class reducer extends Reducer<IntWritable, Text, Text, Text> {

	public void reduce(Iterable<IntWritable> keys, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {
		for (IntWritable key : keys) {
			for (Text value : values) {
				String[] nums1 = value.toString().split(",");

				Integer[] row = new Integer(nums.length);
				for(int i = 0; i < nums.length; i+= 1) {
					row
				}
			}
		}
	}
}