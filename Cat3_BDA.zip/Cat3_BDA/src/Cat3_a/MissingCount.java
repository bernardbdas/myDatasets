package Cat3_a;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.ReduceContext;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

@SuppressWarnings("unused")
public class MissingCount {
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		@SuppressWarnings("deprecation")
		Job job = new Job(conf);

		job.setJobName("Missing Count");
		job.setJarByClass(MissingCount.class);

		job.setMapperClass(MissingCountMapper.class);
		job.setReducerClass(MissingCountReducer.class);

		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(IntWritable.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		System.exit(job.waitForCompletion(true) ? 0 : 1);

	}
}

class MissingCountMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
	private int ctr1 = 0;
	private String[] header;
	private Text columnName = new Text();
	private Text columnHeader;

	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String[] columnFields = value.toString().split("\t");
		ctr1 = 0;
		for (String field : columnFields) {
			if (field.isEmpty()) {
				columnName.set(header[ctr1]);
				context.write(columnName, new IntWritable(1));
			} else {
				columnName.set(header[ctr1]);
				context.write(columnName, new IntWritable(0));
			}
			ctr1++;
		}
	}

	// @ override
	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		try {
			if (context.nextKeyValue()) {
				columnHeader = context.getCurrentValue();
				header = columnHeader.toString().split("\t");
				for (String column : header)
					System.out.println(column);
			}
			while (context.nextKeyValue()) {
				map(context.getCurrentKey(), context.getCurrentValue(), context);
			}
		} finally {
			cleanup(context);
		}
	}
}

class MissingCountReducer extends Reducer<Text, IntWritable, Text, Text> {
	private int counterSum = 0;
	private float total = 0;
	private float percent;
	private Text result = new Text();
	private Text column;
	private Text values;

	public void reduce(Text key, Iterable<IntWritable> values, Context context)
			throws IOException, InterruptedException {
		counterSum = 0;
		total = 0;
		for (IntWritable value : values) {
			counterSum += value.get();
			total++;
		}

		percent = (int) (counterSum * 100 / total);

		StringBuilder b = new StringBuilder();
		b.append(counterSum);
		b.append('\t');
		b.append(percent);

		result.set(b.toString());

		context.write(key, result);
	}

//@ override
	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		column = new Text("ColumnName");
		values = new Text("MissingCount" + "\t" + "Percentage");
		context.write(column, values);
		try {
			while (context.nextKey()) {
				reduce(context.getCurrentKey(), context.getValues(), context);
				// If a back up store is used, reset it
				Iterator<IntWritable> iter = context.getValues().iterator();
				if (iter instanceof ReduceContext.ValueIterator) {
					((ReduceContext.ValueIterator<IntWritable>) iter).resetBackupStore();
				}
			}
		} finally {
			cleanup(context);
		}
	}
}
