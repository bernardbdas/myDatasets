package cat3_a;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class mapper extends Mapper<Object, Text, Text, Text> {
	public int total = 0;
	
	public String[] header;
	public Text columnName = new Text();
	public Text colHdr;
	
	StringBuilder sb = new StringBuilder();
	Text result = new Text();
	
	@Override
	public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		String[] cols = value.toString().split(",");
		
		// to clear the StringBuilder object
		sb.setLength(0);
		
		for(int i = 0; i < header.length; i += 1) {	
			// to get the missing count
			if(cols[i].isEmpty()) {
				context.write(new Text(header[i]), new Text("one"));
			} else {
				context.write(new Text(header[i]), new Text("zero"));
			}
			if(i > 0) {
				sb.append(",");
				sb.append(cols[i]);
			}
		}

		// context.write(new Text("Total"), new Text("one"));
		// sending the (1st col, rest cols) as (key, value) pair to reducer
		context.write(new Text(cols[0]), new Text(sb.toString()));
	}

	@Override
	public void run(Context context) throws IOException, InterruptedException {
		setup(context);
		try {
			if (context.nextKeyValue()) {
				colHdr = context.getCurrentValue();
				header = colHdr.toString().split(",");
				context.write(new Text("ColNames"), colHdr);
			}
			while (context.nextKeyValue()) {
				map(context.getCurrentKey(), context.getCurrentValue(), context);
			}
		} finally {
			cleanup(context);
		}
	}
}
