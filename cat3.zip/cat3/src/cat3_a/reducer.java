package cat3_a;

import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.ReduceContext;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Reducer.Context;

public class reducer extends Reducer<Text, Text, Text, Text> {
	String cols[];
	int missing, total;
	
	public void reduce(Text key, Text values, Context context)
			throws IOException, InterruptedException {
		
		if (key.equals("ColName")) {
			cols = values.toString().split(",");
		}
		missing = 0;
		total = 0;
		for(int i = 0; i < cols.length; i += 1) {
			if (key.equals("cols[i]")) {
				for (Text value : values) {
					if (value.equals("zero")) {
						missing += 1;
					}
				}
			}
		}
		
		if (key.equals("ColName") && key.equals("")) {
			cols = values.toString().split(",");
		}
			for ( value : values) {
				sum += value.get();
			}
	}
}